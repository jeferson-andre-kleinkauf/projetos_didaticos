
public class conta {
	public conta() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	}
		public class Conta {
		       private int numero;
		       private double saldo;
		       public Conta(){
		            
		       }
		       public int getNumero() {
		             return numero;
		       }
		       public void setNumero(int numero) {
		             this.numero = numero;
		       }
		       public double getSaldo() {
		             return saldo;
		       }
		}
	}
